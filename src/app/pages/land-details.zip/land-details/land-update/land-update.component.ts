import { CommonModule } from '@angular/common';
import { Component, Inject } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, Validators } from '@angular/forms';
import { MatButton, MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatOptionModule } from '@angular/material/core';
import { MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';
import { RouterModule } from '@angular/router';
import { LandService } from '../land.service';

@Component({
  selector: 'app-land-update',
  standalone: true,
  imports: [
        CommonModule,
        FormsModule,
        RouterModule,
    
        // Angular Material Modules
        MatCardModule,
        MatFormFieldModule,
        MatInputModule,
        MatSelectModule,
        MatButtonModule,
        MatIconModule,
        MatTableModule,
        MatSortModule,
        MatOptionModule,
        MatDialogModule,
         FormGroup
        
  ],
  templateUrl: './land-update.component.html',
  styleUrl: './land-update.component.css',

})
export class LandUpdateComponent {

  postForm: FormGroup;

  constructor (private fb: FormBuilder, 
               private ps: LandService,
               @Inject(MAT_DIALOG_DATA) public data:any
  )
  {
    this.postForm = this.fb.group({
      title:[this.data.title, Validators.required], 
      content: [this.data.content, Validators.required]
    });
  }

onSubmit(){
  console.log(this.postForm.value,'form value');
  this.ps.update(this.data.id, this.postForm.value).subscribe((data) => {
    console.log('from server');
    location.reload();
  })
}
}
