import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-land-details',
  standalone: true,
  templateUrl: './land-details.component.html',
  styleUrls: ['./land-details.component.css'], 
  imports:[CommonModule, HttpClientModule],
})
export class LandDetailsComponent implements OnInit {
  land: any;


  
  constructor(private route: ActivatedRoute, private http: HttpClient) {}

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    this.http.get(`http://localhost:5556/anislag/${id}`).subscribe(data => {
      this.land = data;
    });
  }
   
}
